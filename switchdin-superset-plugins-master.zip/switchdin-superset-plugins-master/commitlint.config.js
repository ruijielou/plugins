module.exports = require('@superset-ui/commit-config/commitlint.config');
