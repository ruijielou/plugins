## @switchdin-superset/switchdin-superset-plugin-big-number-image

This plugin provides A BigNumber with an image from @switchdin-superset/switchdin-superset-plugin-image-assets

### Usage

Can be used to to display a metric alongside an image.


```js
Add some code.
```

```js
Add some code.
```
