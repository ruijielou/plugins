## @switchdin-superset/switchdin-superset-plugin-weather

Show a weather dial from OpwnWeatherMap.

### Usage

Add a description.


```js
Add some code.
```

```js
Add some code.
```
