## @switchdin-superset/switchdin-superset-plugin-color

SwitchDin Color Schemes.


### Usage

Add a description.


```js
Add some code.
```

```js
Add some code.
```
