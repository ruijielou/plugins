## @switchdin-superset/switchdin-superset-rich-image

Run arbitrary substitutions on SVG image asset.

### Usage

Add a description.


```js
Add some code.
```

```js
Add some code.
```
