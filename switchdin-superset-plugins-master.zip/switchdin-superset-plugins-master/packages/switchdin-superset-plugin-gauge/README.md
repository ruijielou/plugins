## @switchdin-superset/switchdin-superset-gauge

Show an indicator gauge.

### Usage

Add a description.


```js
Add some code.
```

```js
Add some code.
```
